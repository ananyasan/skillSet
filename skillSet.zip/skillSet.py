#connect database with python, mysql connection using import
import datetime
import mysql.connector

conn= mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='W@2915djkq#',
    database='employeeSkillSet'
)

#creating table if not exists
cursor = conn.cursor()

cursor.execute(
    """
    CREATE TABLE IF NOT EXISTS employee 
    ( 
    emp_id INT PRIMARY KEY, 
    emp_name VARCHAR(255), 
    emp_salary INT, 
    emp_specialization VARCHAR(255),
    emp_hireDate DATE,
    emp_projectStatus ENUM('P' , 'N') DEFAULT 'N'
    )
    """
)
conn.commit()

def display_menu():
    print("~~~EMPLOYEE SKILL INVENTORY MANAGEMENT~~~")
    print("1. ADD A NEW EMPLOYEE")
    print("2. VIEW ALL THE EMPLOYEES")
    print("3. REMOVE AN EMPLOYEE")
    print("4. SEARCH EMPLOYEE BY EMPLOYEE ID")
    print("5. SEARCH EMPLOYEE BY EMPLOYEE NAME")
    print("6. UPDATE PROJECT STATUS")
    print("7. PROJECT REQUIREMENT")
    print("8. EXIT")

def add_emp():
    emp_hireDate= None
    while True:
        emp_id= input("Enter the Employee ID:")
        if not emp_id.isdigit():
            print("Invalid Input. Employee ID can only have numbers.")
            continue
        emp_id=int(emp_id)
        #break

        while True:
            emp_name = input("Enter the Employee Name:")
            if not emp_name.isalpha():
                print("Invalid Input. Employee name can only have alphabets.")
            break


        while True:
            emp_salary = input("Enter the Employee Salary:")
            if not emp_salary.isdigit():
                print("Invalid Input. Employee Salary can only have numbers.")
                continue
            emp_salary = int(emp_salary)
            break

        while True:
            emp_specialization = input("Enter the Skills Employee has a specialization in: ")
            if all(word.strip().replace(',', '').replace(' ', '').isalpha() for word in emp_specialization.split(',')):
                break  # Exit the loop if the input is valid
            else:
                print("Invalid Input. Can only contain alphabets, commas, and spaces.")

        # emp_hireDate= input("Enter the Employee Hiring Date:")
        while True:
            emp_hireDate = input("Enter the Employee Hiring Date (YYYY-MM-DD): ")
            try:
                hire_date = datetime.date.fromisoformat(emp_hireDate)
                break  # Exit the loop if the input is valid
            except ValueError:
                    print("Incorrect data format, should be YYYY-MM-DD")
        cursor.execute("""
            INSERT INTO employee (emp_id, emp_name, emp_salary, emp_specialization, emp_hireDate) 
            VALUES (%s, %s, %s, %s, %s)
        """, (emp_id, emp_name, emp_salary, emp_specialization, emp_hireDate))
        conn.commit()
        print("Employee Details added Successfully!")

def view_items():
    cursor.execute('SELECT * FROM employee')
    employees= cursor.fetchall()

    if not employees:
        print("No employees in the database.")
    else:
        for employee in employees:
            print(f" ID:{employee[0]}, NAME:{employee[1]}, SALARY:{employee[2]}, HIRING DATE:{employee[3]}, SKILL SET:{employee[4]}, WORKING STATUS:{employee[5]}")

def update_project_status():
    emp_projectStatus= input("Enter the ID of the whose Status needs to be changed:")
    new_emp_projectStatus= input("Enter the current bench status of the Employee:")

    cursor.execute('UPDATE employee SET emp_projectStatus = ? WHERE emp_id = ?',(new_emp_projectStatus,emp_projectStatus))
    conn.commit()
    print("Project Status Updated Successfully!")

def search_employee_by_name():
    emp_name=input("Enter the name to search for: ")
    cursor.execute('SELECT * FROM employee WHERE emp_name LIKE ?', ('%'+ emp_name + '%',))
    employees= cursor.fetchall()

    if not employees:
        print("Employee not Found.")
    else:
        for employee in employees:
            print(f" ID:{employee[0]}, NAME:{employee[1]}, SALARY:{employee[2]}, HIRING DATE:{employee[3]}, SKILL SET:{employee[4]}, WORKING STATUS:{employee[5]}")

def search_employee_by_id():
    emp_name=input("Enter the ID to search for: ")
    cursor.execute('SELECT * FROM employee WHERE emp_id LIKE ?', ('%'+ emp_id + '%',))
    employees= cursor.fetchall()

    if not employees:
        print("Employee not Found.")
    else:
        for employee in employees:
            print(f" ID:{employee[0]}, NAME:{employee[1]}, SALARY:{employee[2]}, HIRING DATE:{employee[3]}, SKILL SET:{employee[4]}, WORKING STATUS:{employee[5]}")

def remove_employee():
    emp_id= int(input("Enter the employee ID to remove: "))
    cursor.execute('DELETE FROM employee WHERE item_id = ?', (emp_id,))
    conn.commit()
    print("Employee removed Successfully!")

    #retrieve remaining items and renumber Employess IDs in increasing format
    cursor.execute('SELECT * FROM employee ORDER BY emp_id')
    employees= cursor.fetchall()

def project_requirement():
    emp_specialization= input("Enter the skills required for the Project:")
    cursor.execute('SELECT * FROM employee WHERE emp_specialization LIKE ? AND emp_projectStatus ="N" ',('%'+ emp_specialization + '%',))
    employees = cursor.fetchall()

    if not employees:
        print("Employee not Found.")
    else:
        for employee in employees:
            print(
                f" ID:{employee[0]}, NAME:{employee[1]}, SALARY:{employee[2]}, HIRING DATE:{employee[3]}, SKILL SET:{employee[4]}, WORKING STATUS:{employee[5]}")
def main():
    while True:
        display_menu()
        choice= input("Enter your choice: ")
        if choice== "1":
            add_emp()
        elif choice=="2":
            view_items()
        elif choice=="3":
            remove_employee()
        elif choice=="4":
            search_employee_by_id()
        elif choice=="5":
            search_employee_by_name()
        elif choice=="6":
            update_project_status()
        elif choice=="7":
            project_requirement()
        elif choice=="8":
            print("Exiting the program.")
            break
        else:
            print("Invalid Choice. Please try again.")
if __name__== "__main__":
    main()
    conn.close()


